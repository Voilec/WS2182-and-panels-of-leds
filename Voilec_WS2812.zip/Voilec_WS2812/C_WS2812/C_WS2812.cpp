//***********************************//
//            WS 2812                //
//***********************************//
//        Christian Couderc          //
//         www.voilec.com            //
//***********************************//
//   240701

#include <C_WS2812.h>

//C_WS2812::C_WS2812(uint16_t n, int16_t pin, uint8_t brightness, neoPixelType type) : Adafruit_NeoPixel(n, pin, type)
C_WS2812::C_WS2812(uint16_t n, int16_t pin, neoPixelType type) : Adafruit_NeoPixel(n, pin, type)
{
}	
// ************************************
// Special init for my card 2308 with Mosfet and 3 WS2812
void C_WS2812::init3(uint8_t _SwitchWS, uint8_t _LedBlue) 
{ 
SwitchWS = _SwitchWS;
LedBlue = _LedBlue;
pinMode (SwitchWS,OUTPUT); // Pin definition is in <C_Config_ESP32_S3.h>
pinMode (LedBlue,OUTPUT); // Pin definition is in <C_Config_ESP32_S3.h>
digitalWrite(LedBlue, LOW);   // turn the LED on
digitalWrite (SwitchWS, LOW); // Switch on power on leds
delay (500);
begin(); 
setBrightness (brightness);
clear();
show();
delay (500);
killWs();  // Switch Off VDD on leds
}
// ************************************

void C_WS2812::init(uint8_t LedBlue) 
{
SwitchWS = 0 ; //Discard the 3 led card
begin(); 
setBrightness (brightness);
clear();
show(); 
}
// ******************************

void C_WS2812::pixColor (uint8_t led, uint32_t color) 
{
//Serial.print (millis()); Serial.print ("  <<<  pixColor start <<<  digitalRead : "); Serial.println (digitalRead (SwitchWS));
if ((SwitchWS!=0) && (digitalRead (SwitchWS)) == HIGH) // Initialise and set power
	{
	//Serial.print (millis()); Serial.print (" 11111111 pixColor 0 digitalRead : "); Serial.println (digitalRead (SwitchWS));
	digitalWrite (SwitchWS, LOW); // Switch on power on leds
	delay (100);
	begin(); 
	setBrightness (255);
	Serial.println ("            ___________ LOW pixcolor __ VDD ON ______________");  
	}	
setPixelColor(led,color); // Original one
}
// ****************************************

void C_WS2812::killWs()  // Switch Off VDD on leds
{
clear();
show();
if (SwitchWS!=0) 
	digitalWrite (SwitchWS, HIGH); // Stop current on 3 leds
//Serial.println ("\n           ++++++++++++++++ HIGH kill +++++++++++++"); 
}
// ****************************************

void C_WS2812::del_SwitchOff(long before, long after)
{
delay (before);
killWs(); // Switch Off VDD on leds
delay (after);
}
// ****************************************

const uint32_t C_WS2812::rainbow[]={RED,RE2,RE1, YEL,YE2,YE1, GRN,GR2,GR1, CYA,CY2,CY1, BLU,BL2,BL1,
MAG,MA2,MA1, ORA,OR2,OR1, WHI,WH2,WH1, BLK,BLK,BLK};
const uint8_t C_WS2812::sizeRainbow = (sizeof(rainbow)/sizeof(uint32_t));

const char* C_WS2812::colorText[]={"Red ","Yellow","Green","Cyan","Blue","Magenta","Orange","White","Black"};

// ******************************

void C_WS2812::banner()  // Shows small french banner only on 3 firsts leds
{
Serial.println ("\nFrench banner");
pixColor(0, BL2); // Blue
pixColor(1, WH2); // White
pixColor(2, RE2); // Red
show(); 
}
// ******************************

int8_t C_WS2812::ledRankCol(uint32_t color) // RED returns 0
{
uint8_t i;
for (i=0; i<13; i++)   
  {
  if (color==rainbow[i])
  break;
  }
return i; // Number of the color in rainbow[]  0..13 (if error : BLACK)
}
// ******************************

const char* C_WS2812::nameCol(uint8_t colorNb) // 0 returns text: Red
{
if (colorNb<sizeColTxt) 
  return (colorText[colorNb]); //  Name of the color  Red. . Black)
else
  return "???";
}

// ******************************

void C_WS2812::sevenColors() 
{
clear();
uint16_t add=0;
for (int i=0; i<sizeRainbow ; i++)
  {
  Serial.print (i);Serial.print ("\t");Serial.print (colorText[i/3]);
  Serial.print ("\t-> ");Serial.println (rainbow[i],HEX);
  for (int j=0; j<8; j++)
    pixColor(add++,rainbow[i]);    
  
  if (i%3==2)
     add+=8;
        
  show(); 
  delay(100);
  }
}
// ******************************

void C_WS2812::sevenColors2() // only for panel 8*32
{
clear();
int k;
Serial.println ("sevenColors2()");
for (int i=0; i<32; i++) // columns
  {
  Serial.print (i);Serial.print ("\t");Serial.println (i);

  for (int j=0; j<32; j++)
  {
  if (i%2==0)
	  k=32*i +j;
  else
	  k=32*i +8-i;
	 
  pixColor(k,(8*j)+i);    
    show(); 
delay(300); 
	}
  } 
}
// ***********************************************************
// *************** For 3 leds only : *************************

/*void C_WS2812::flashAll (uint32_t color)  // Animation on the 3 leds
{
flashAll (color,10);  
}*/

// ****************************************

void C_WS2812::flashAll (uint32_t color, int ms) 
{
pulse (0,color,ms);
pulse (1, color,ms);
pulse (2,color,ms);
killWs();
}
// ****************************************

void C_WS2812::pulse (uint8_t ledPos, uint32_t color, int ms, uint8_t loopsNb)
{
// default loopsNb=10;
sprintf (buffer ,"Pulse  -> ledPos: %d  color: 0x%06X  delay: %d loopsNb: %d",ledPos, color, ms,loopsNb);
Serial.println (buffer);
clear();

for (uint8_t i=0; i<loopsNb ;i++)
  {
  if (ledPos ==254)   // 254 = Magic number....
	for (uint8_t n=0; n<3; n++) // Only for 3 leds card !
		pixColor(n,color);
  else
  pixColor(ledPos,color);
  show();
  delay (ms);
  clear();
  show();
  delay (5*ms);
  }
killWs();
}
// ****************************************

void C_WS2812::dimmer (uint32_t color,int ms) // Reduce slowly
{
sprintf (buffer ,"\nDimmer  -> color: 0x%06X  delay: %d", color, ms);
Serial.println (buffer);
uint8_t rd, gn,bl;
while (color!=0)
	{
	rd = (color/0x10000);
	gn = (color/0x100)&0xFF;
	bl = color&0xFF;   

	if (rd>.9)
		rd/=1.4;
	if (gn>.9)
		gn/=1.4;
	if (bl>.9)
		bl/=1.4;

	color = (rd*0x10000)+(gn*0x100)+ bl;
	pixColor(0,color);
	pixColor(1,color);
	pixColor(2,color);
    show();
	delay (ms);  
    }
killWs();
}
// ****************************************

void C_WS2812::sweep (uint32_t color, uint8_t lop, int ms) // Reduce slowly
{
sprintf (buffer ,"\nSweep   lp:%d   %d msec", lop, ms);
Serial.println (buffer);
while (lop--!=0)
  {
  for (uint8_t ledPos=0; ledPos<3; ledPos++)
    {
    pixColor((ledPos+3)%3,color);
    pixColor((ledPos+4)%3,0);
    pixColor((ledPos+5)%3,0);
    show();
    delay (ms);
    }  
  }  
killWs();
}
// ****************************************

void C_WS2812::cligno (uint32_t color, uint8_t lop, int ms) // 010 -> 101
{
sprintf (buffer ,"\nCligno   lp:%d   %d msec", lop, ms);
Serial.println (buffer);
while (lop--!=0)
  {
  pixColor(0,color);
  pixColor(1,BLK);
  pixColor(2,color);
  show();
  delay (ms);
  pixColor(0,BLK);
  pixColor(1,color);
  pixColor(2,BLK);
  show();
  delay (ms);
  }  
killWs();
}
// ****************************************

void C_WS2812::rainbow3 (uint8_t lop, int ms, uint8_t offs) 
{
    //      digitalWrite (SwitchWS, LOW); // Switch on power on leds//digitalWrite (SwitchWS, LOW);
Serial.print (millis()); Serial.print ("  <<rainbow3<<  digitalRead : "); Serial.println (digitalRead (SwitchWS));
offs%=3;
sprintf (buffer ,"\nRainbow3   loops:%d   %d msec   offset:%d <0=full, 2=low> ", lop, ms, offs);
Serial.println (buffer);

for (uint16_t lp=0; lp<3*lop; lp+=3)
  {
  pixColor(0,rainbow[(lp+offs)%(sizeRainbow-3)]);
  pixColor(1,rainbow[(lp+offs+3)%(sizeRainbow-3)]);
  pixColor(2,rainbow[(lp+offs+6)%(sizeRainbow-3)]);
  /* Serial.print(lp);
	Serial.print("  ---> ");
	Serial.print(rainbow[(lp+offs)%(sizeRainbow-3)],HEX);
	Serial.print("  ...  ");
	Serial.print(rainbow[(lp+offs+3)%(sizeRainbow-3)],HEX);
	Serial.print("  ...  ");
	Serial.print(rainbow[(lp+offs+6)%(sizeRainbow-3)],HEX);
	Serial.println("");*/
  
	show(); 
	delay (ms);
	}  
killWs();
}
// ****************************************

void C_WS2812::delayBlue (uint16_t _delay)
{
digitalWrite(LedBlue, LOW);   // turn the LED on	
delay (_delay)	;
digitalWrite(LedBlue, HIGH);   // turn the LED off_type
}

// ****************************************