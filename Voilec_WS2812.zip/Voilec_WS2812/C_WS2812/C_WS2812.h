//***********************************//
//            WS 2812                //
//***********************************//
//        Christian Couderc          //
//         www.voilec.com            //
//***********************************//
//   240701

#ifndef _CWS2812_ 
#define _CWS2812_

#include <Arduino.h>
#include <Adafruit_NeoPixel.h>

// ****************************** BLU//Very difficult to adjust !
#define RED    (uint32_t)0xFF0000  // RED  -> full luminosity
#define RE2    (uint32_t)0x070000  // RED  -> medium luminosity
#define RE1    (uint32_t)0x020000  // RED  -> low luminosity

#define YEL    (uint32_t)0xFF7F00  // YELLOW  -> full luminosity
#define YE2    (uint32_t)0x1F1000  // YELLOW  -> medium luminosity  
#define YE1    (uint32_t)0x010100  // YELLOW  -> low luminosity  

#define GRN    (uint32_t)0x00FF00  // GREEN  -> full luminosity
#define GR2    (uint32_t)0x001000  // GREEN  -> medium luminosity
#define GR1    (uint32_t)0x000100  // GREEN  -> low luminosity
  
#define CYA    (uint32_t)0x004040  // CYAN  -> full luminosity 
#define CY2    (uint32_t)0x000808  // CYAN  -> medium luminosity
#define CY1    (uint32_t)0x000101  // CYAN  -> low luminosity 
 
#define BLU    (uint32_t)0x0000FF  // BLUE  -> full luminosity
#define BL2    (uint32_t)0x000030  // BLUE  -> medium luminosity
#define BL1    (uint32_t)0x000003  // BLUE  -> low luminosity  
  
#define MAG    (uint32_t)0x7F007F  // MAGENTA  -> full luminosity
#define MA2    (uint32_t)0x100010  // MAGENTA  -> medium luminosity
#define MA1    (uint32_t)0x020002  // MAGENTA  -> low luminosity

#define ORA    (uint32_t)0xFF2000  // ORANGE  -> full luminosity
#define OR2    (uint32_t)0x100300  // ORANGE  -> medium luminosity 
#define OR1    (uint32_t)0x030100  // ORANGE  -> low luminosity 

#define WHI    (uint32_t)0xFFFFFF  // WHITE  -> full luminosity
#define WH2    (uint32_t)0x040404  // WHITE  -> medium grey
#define WH1    (uint32_t)0x010101  // WHITE  -> low grey  

#define BLK    (uint32_t)0x000000  // BLACK  
#define BK2    (uint32_t)0x000000  // BLACK 
#define BK1    (uint32_t)0x000000  // BLACK 

#define sizeColTxt 9

// ******************************

class C_WS2812 : public Adafruit_NeoPixel
{                       
private:
uint8_t brightness = 255;
uint8_t SwitchWS;
uint8_t LedBlue;
char buffer[50];
protected:           

public:
// Constructor: number of LEDs, pin number, LED type, brightness
//C_WS2812(uint16_t n, int16_t pin=6, uint8_t brightness, neoPixelType type = NEO_GRB + NEO_KHZ800);
C_WS2812(uint16_t n, int16_t pin, neoPixelType type = NEO_GRB + NEO_KHZ800);
static const uint32_t rainbow[27];// 9*3 
static const uint8_t sizeRainbow; 

static const char* colorText[9];

int8_t ledRankCol(uint32_t color); // RED returns 0
const char* nameCol(uint8_t colorNb); // 0 returns RED


void init3(uint8_t _switchWS, uint8_t _LEDBLUE);
void init(uint8_t LEDBLUE);
void del_SwitchOff(long before=1000, long after=1000);
void banner(); // Shows french banner
void sevenColors(); 
void sevenColors2();
//************* 3 leds only **********

void pixColor (uint8_t led, uint32_t color); 
void killWs(); // Switch Off VDD on 3 leds
void flash3 (uint32_t color, int ms);
void flashAll (uint32_t color, int ms=10); // Animation on the 3 leds
void pulse (uint8_t ledNb, uint32_t color, int ms, uint8_t loopsNb=10);
void dimmer (uint32_t color, int ms); // Reduce slowly
void sweep (uint32_t color, uint8_t lp=10, int ms= 200); // Reduce slowly
void cligno (uint32_t color, uint8_t lp=10, int ms=300); // 010 -> 101
void rainbow3 (uint8_t lp=10, int ms=1000, uint8_t offs=1); 
void delayBlue (uint16_t _delay);
};
// ****************
#endif